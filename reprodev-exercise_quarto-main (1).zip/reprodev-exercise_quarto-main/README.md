# reprodev-exercise_quarto

<!-- badges: start -->
<!-- badges: end -->

The goal of this repository is to create a reproducible research compendium. The compendium has been generated on Thursday March 14, 2023 by [Gerko Vink](https://www.gerkovink.com) as part of the course [Reproducible Programming and Development](https://www.gerkovink.com/reprodev).

Use ever which way you like to use it. 

The rendered `Quarto` file can be found [here](/doc/reprodev-exercise_quarto.html)
