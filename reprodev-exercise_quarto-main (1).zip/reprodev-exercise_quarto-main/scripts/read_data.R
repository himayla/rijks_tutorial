# Read data
boys <- read.csv("../data/data.csv")[, -1]
